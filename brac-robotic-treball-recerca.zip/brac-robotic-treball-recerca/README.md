# BRAÇ ROBÒTIC PER AJUDAR PERSONES AMB DISCAPACITATS

Aquest repositori forma part del **Treball de Recerca** i conté el **codi en C++** i els **fitxers 3D** del projecte *Braç robòtic per ajudar persones amb discapacitats*.

---

## 👤 DADES DEL PROJECTE
- **Autor:** Miquel Monserrat Palau  
- **Curs:** 2 BATX - A  
- **Projecte:** Braç robòtic per ajudar persones amb discapacitats

---

## 🎯 OBJECTIUS
- Dissenyar i fabricar un braç robòtic funcional i accessible.
- Programar el control amb servomotors i rutes de moviment bàsiques.
- Integrar sensors (opcional) per millorar precisió i seguretat.
- Documentar muntatge, connexions i ús.

---

## 🧩 ESTRUCTURA DEL REPOSITORI

| Carpeta | Descripció |
|---|---|
| `/codi` | Codi font en C++ (fitxers `.cpp` i `.h`) per al control del braç. |
| `/peces_3D` | Models 3D de les peces (formats recomanats: `.stl`, `.step`). |
| `/imatges` | Fotografies, renders o esquemes. |
| `/docs` | Documentació addicional (esquemes, memòries, instruccions). |

---

## ⚙️ REQUERIMENTS DE MAQUINARI
- **Placa Arduino UNO o similar**  
- **Servomotors** (p. ex. SG90, MG90S o MG996R segons càrrega)  
- **Font d'alimentació 5V estable** (mín. 2A si hi ha diversos servos)  
- **Cables Dupont, brida i cargols**  
- **Sensors opcionals** (potenciòmetres, final de cursa, etc.)

---

## 💻 COMPILACIÓ I CÀRREGA (C++)
1. Obre **Arduino IDE** (o altra eina compatible amb C++ i Arduino).
2. Importa els fitxers del directori `/codi`.
3. Revisa i ajusta els **pins** dels servos i sensors a `control_servos.h`.
4. Connecta la placa via USB i prem **Upload**.

> Si prefereixes **CMake/PlatformIO**, afegeix la configuració corresponent dins `/codi`.

---

## 🖨️ PECES 3D I MUNTATGE
1. A `/peces_3D` trobaràs els fitxers per imprimir (PLA o PETG recomanats).
2. Muntatge recomanat:
   - Fixa la base al suport.
   - Col·loca els servos als allotjaments i centra’ls abans de fixar-los.
   - Uneix segments i pinça, verificant llibertats de moviment.
   - Alimenta i prova moviments suaus abans d’esforços.

---

## ▶️ DEMOSTRACIÓ
Afegeix fotos a `/imatges` i (opcionalment) un vídeo de demostració amb enllaç al README.

---

## 🧪 PROVES RÀPIDES
Després de carregar el firmware, el braç executarà un petit **self-test** que pots activar a `main.cpp`. Serveix per verificar endreçament de servos i alimentació.

---

## 📦 FITXERS GRANS (GIT LFS)
Si algun model 3D supera **100 MB**, cal usar **Git LFS**. Aquest repositori ja inclou `.gitattributes` per rastrejar `*.stl` i `*.step`.

```bash
git lfs install
git lfs track "*.stl" "*.step"
git add .gitattributes
git add peces_3D/*
git commit -m "Afegides peces 3D amb LFS"
git push
```

---

## 📜 LLICÈNCIA
Aquest treball es publica sota **Llicència MIT** (vegeu `LICENSE`).

---

## ✉️ CONTACTE
Si tens dubtes o suggeriments, obre una **Issue** o un **Discussion** al repositori.
