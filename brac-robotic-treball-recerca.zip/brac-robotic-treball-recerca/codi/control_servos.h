#pragma once

// Defineix aquí els pins dels teus servos (ajusta segons el cablejat)
static const int SERVO_BASE_PIN = 3;
static const int SERVO_ESPAULAT_PIN = 5;
static const int SERVO_COTZE_PIN = 6;
static const int SERVO_MUNYICA_PIN = 9;
static const int SERVO_PINCA_PIN = 10;

// Funcions d'inicialització i moviment
void initServos();
void moveToAngles(int base, int esp, int cotze, int muny, int pinca);
void selfTest();
