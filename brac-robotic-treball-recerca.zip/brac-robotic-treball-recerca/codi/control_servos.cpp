#include <Arduino.h>
#include <Servo.h>
#include "control_servos.h"

Servo sBase, sEsp, sCotze, sMuny, sPinca;

void initServos() {
  sBase.attach(SERVO_BASE_PIN);
  sEsp.attach(SERVO_ESPAULAT_PIN);
  sCotze.attach(SERVO_COTZE_PIN);
  sMuny.attach(SERVO_MUNYICA_PIN);
  sPinca.attach(SERVO_PINCA_PIN);

  // Centrar servos
  moveToAngles(90, 90, 90, 90, 90);
  delay(500);
}

void moveToAngles(int base, int esp, int cotze, int muny, int pinca) {
  sBase.write(constrain(base, 0, 180));
  sEsp.write(constrain(esp, 0, 180));
  sCotze.write(constrain(cotze, 0, 180));
  sMuny.write(constrain(muny, 0, 180));
  sPinca.write(constrain(pinca, 0, 180));
}

void selfTest() {
  // Petit recorregut per verificar connexions i alimentació
  for (int angle = 60; angle <= 120; angle += 20) {
    moveToAngles(angle, 180 - angle, angle, 180 - angle, angle);
    delay(400);
  }
  moveToAngles(90, 90, 90, 90, 90);
}
