#include "control_servos.h"

/**
 * BRAÇ ROBÒTIC PER AJUDAR PERSONES AMB DISCAPACITATS
 * Autor: Miquel Monserrat Palau
 * Curs: 2 BATX - A
 *
 * Aquest programa inicialitza els servos i executa una prova bàsica de moviment.
 */

void setup() {
  initServos();
  // Prova simple: moure cada servo a posicions bàsiques
  selfTest();
}

void loop() {
  // Aquí pots afegir seqüències de moviment o lectura de sensors
  // moveToAngles(90, 45, 30, 15);
  // delay(1000);
}
